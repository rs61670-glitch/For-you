import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { format, addDays, subDays, startOfToday } from 'date-fns';
import { th, enUS } from 'date-fns/locale';
import { Plus, ChevronLeft, ChevronRight, Calendar as CalendarIcon, Settings, Activity, Shield, Target, Globe, Cpu, Clock } from 'lucide-react';
import { useScheduleStore } from './store';
import { ScheduleTask } from './types';
import ScheduleGrid from './components/ScheduleGrid';
import TaskModal from './components/TaskModal';
import AIScheduler from './components/AIScheduler';
import CalendarPicker from './components/CalendarPicker';
import Login from './components/Login';
import ThemeCustomizer from './components/ThemeCustomizer';
import { sounds } from './utils/sounds';

export default function App() {
  const { 
    user, 
    profile, 
    tasks, 
    isLoaded, 
    login, 
    loginWithEmail,
    registerWithEmail,
    logout, 
    addTask, 
    updateTask, 
    deleteTask, 
    setTheme, 
    setLanguage 
  } = useScheduleStore();

  const [selectedDate, setSelectedDate] = useState(startOfToday());
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<ScheduleTask | null>(null);

  const theme = profile?.theme || 'cyberpunk';
  const language = profile?.language || 'en';

  // Apply theme class to body
  useEffect(() => {
    document.body.className = `theme-${theme}`;
  }, [theme]);

  const handlePrevDay = () => { sounds.startAmbientMusic(); sounds.playClick(); setSelectedDate(prev => subDays(prev, 1)); };
  const handleNextDay = () => { sounds.startAmbientMusic(); sounds.playClick(); setSelectedDate(prev => addDays(prev, 1)); };
  const handleToday = () => { sounds.startAmbientMusic(); sounds.playClick(); setSelectedDate(startOfToday()); };

  const handleSaveTask = (task: ScheduleTask) => {
    sounds.playSave();
    if (editingTask) {
      updateTask(task);
    } else {
      addTask(task);
    }
  };

  const openNewTaskModal = () => {
    sounds.startAmbientMusic();
    sounds.playClick();
    setEditingTask(null);
    setIsModalOpen(true);
  };

  const openEditTaskModal = (task: ScheduleTask) => {
    sounds.startAmbientMusic();
    sounds.playClick();
    setEditingTask(task);
    setIsModalOpen(true);
  };

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
          className="w-12 h-12 border-4 border-cyber-blue/20 border-t-cyber-blue rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <Login 
        onLogin={login} 
        onEmailLogin={loginWithEmail} 
        onEmailRegister={registerWithEmail} 
      />
    );
  }

  const dateLocale = language === 'th' ? th : enUS;
  const t = (en: string, th: string) => language === 'th' ? th : en;

  const totalTasks = tasks.filter(t => {
    if (t.recurrence === 'once') return t.date === format(selectedDate, 'yyyy-MM-dd');
    if (t.recurrence === 'daily') return true;
    if (t.recurrence === 'weekly') return t.daysOfWeek?.includes(selectedDate.getDay());
    if (t.recurrence === 'weekdays') {
      const day = selectedDate.getDay();
      return day >= 1 && day <= 5;
    }
    return false;
  }).length;

  return (
    <div className="min-h-screen flex flex-col p-4 md:p-8 lg:px-20 max-w-[1600px] mx-auto relative overflow-x-hidden transition-colors duration-500">
      {/* Immersive Background Elements */}
      <div className="noise" />
      
      {/* HUD Borders & Accents */}
      <div className="fixed inset-0 pointer-events-none border-[1px] border-white/5 m-4 md:m-8 z-50" />
      
      {/* Side Decorative Rails */}
      <div className="fixed left-0 top-0 bottom-0 w-20 hidden xl:flex flex-col items-center py-20 gap-12 border-r border-white/5 pointer-events-none opacity-20" />
      <div className="fixed right-0 top-0 bottom-0 w-20 hidden xl:flex flex-col items-center py-20 gap-12 border-l border-white/5 pointer-events-none opacity-20" />

      {/* Header Section */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8 mb-16 relative z-10">
        <motion.div 
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ type: "spring", damping: 20 }}
          className="space-y-6"
        >
          <div className="flex flex-wrap items-center gap-4">
            <motion.div 
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="flex items-center gap-2 text-cyber-blue font-mono text-[10px] tracking-[0.4em] uppercase bg-cyber-blue/5 px-4 py-1.5 border border-cyber-blue/20"
            >
              <Activity size={12} />
              {t('SYSTEM_STATUS: OPTIMAL', 'สถานะระบบ: ปกติ')}
            </motion.div>
            <div className="flex items-center gap-2 text-white/20 font-mono text-[10px] tracking-[0.4em] uppercase">
              <Shield size={12} />
              {t('SECURE_LINK_ESTABLISHED', 'การเชื่อมต่อปลอดภัย')}
            </div>
            <div className="flex items-center gap-2 text-matrix-green font-mono text-[10px] tracking-[0.4em] uppercase bg-matrix-green/5 px-4 py-1.5 border border-matrix-green/20">
              <Clock size={12} />
              {format(currentTime, 'HH:mm:ss')}
            </div>
          </div>
          
          <div className="relative">
            <h1 className="text-8xl md:text-[10rem] font-black italic uppercase tracking-tighter leading-[0.8] mix-blend-difference glitch-text" data-text="AETHER_CORE">
              AETHER<span className="text-cyber-blue">_</span>CORE
            </h1>
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ delay: 0.5, duration: 1 }}
              className="absolute -bottom-2 left-0 h-1 bg-white/10"
            />
          </div>

          <div className="flex items-center gap-6">
            <p className="text-white/40 font-mono text-[10px] uppercase tracking-[0.5em] whitespace-nowrap">
              {t('Temporal_Interface // v2.5.0_REV_A', 'อินเตอร์เฟซเวลา // v2.5.0_REV_A')}
            </p>
            <div className="h-[1px] flex-1 bg-gradient-to-r from-white/20 to-transparent" />
          </div>
        </motion.div>

        <motion.div 
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ type: "spring", damping: 20 }}
          className="flex flex-col items-end gap-6"
        >
          <div className="flex items-center gap-6">
            <motion.button 
              whileHover={{ scale: 1.1, x: -5 }}
              whileTap={{ scale: 0.9 }}
              onClick={handlePrevDay}
              className="p-4 hover:bg-white text-white hover:text-black transition-all border border-white/10 hover:border-white group"
            >
              <ChevronLeft size={24} className="group-hover:scale-110 transition-transform" />
            </motion.button>
            
            <div className="text-right flex flex-col items-end">
              <motion.div 
                key={selectedDate.getTime()}
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="text-6xl md:text-7xl font-black tracking-tighter italic leading-none text-white flex items-baseline gap-2"
              >
                {format(selectedDate, 'dd')}
                <span className="text-xs font-mono text-cyber-blue not-italic tracking-widest uppercase">{format(selectedDate, 'EEE', { locale: dateLocale })}</span>
              </motion.div>
              <div className="text-[9px] uppercase tracking-[0.4em] text-white/40 font-mono mt-1">
                {format(selectedDate, 'MMMM_yyyy', { locale: dateLocale })}
              </div>
            </div>

            <motion.button 
              whileHover={{ scale: 1.1, x: 5 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleNextDay}
              className="p-4 hover:bg-white text-white hover:text-black transition-all border border-white/10 hover:border-white group"
            >
              <ChevronRight size={24} className="group-hover:scale-110 transition-transform" />
            </motion.button>
          </div>

          <div className="flex gap-3">
            <button 
              onClick={handleToday} 
              className="text-[9px] font-black uppercase tracking-[0.2em] px-6 py-2.5 border border-white/10 hover:border-white hover:bg-white hover:text-black transition-all relative overflow-hidden group"
            >
              <span className="relative z-10">{t('PRESENT', 'ปัจจุบัน')}</span>
              <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </button>
            <button 
              onClick={() => { sounds.startAmbientMusic(); sounds.playClick(); setIsCalendarOpen(true); }}
              className="text-[9px] font-black uppercase tracking-[0.2em] px-5 py-2.5 border border-cyber-blue/20 text-cyber-blue hover:bg-cyber-blue hover:text-black transition-all flex items-center gap-2 group"
            >
              <CalendarIcon size={12} className="group-hover:rotate-12 transition-transform" />
              {t('JUMP', 'ข้าม')}
            </button>
            <button 
              onClick={() => { sounds.playClick(); setIsThemeOpen(true); }}
              className="w-10 h-10 flex items-center justify-center border border-white/10 text-white/40 hover:text-cyber-blue hover:border-cyber-blue transition-all rounded-xl group"
            >
              <Settings size={18} className="group-hover:rotate-90 transition-transform duration-500" />
            </button>
          </div>
        </motion.div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col lg:flex-row gap-16 relative z-10">
        {/* Sidebar / Stats */}
        <aside className="w-full lg:w-96 space-y-12">
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="p-10 border-2 border-white/5 bg-white/[0.02] backdrop-blur-md relative group overflow-hidden"
          >
            {/* Decorative Corner */}
            <div className="absolute top-0 right-0 w-12 h-12 border-t-2 border-r-2 border-cyber-blue/40" />
            <div className="absolute bottom-0 left-0 w-12 h-12 border-b-2 border-l-2 border-electric-purple/40" />
            
            <div className="absolute top-4 right-4 opacity-10">
              <Target size={64} className="group-hover:rotate-45 transition-transform duration-700" />
            </div>

            <h3 className="text-[10px] font-mono uppercase tracking-[0.4em] text-white/30 mb-8 flex items-center gap-3">
              <Activity size={14} className="text-cyber-blue" /> 
              {t('OPERATIONAL_METRICS', 'ตัวชี้วัดการทำงาน')}
            </h3>

            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-mono text-white/40 uppercase mb-1">{t('Current_Cycle', 'รอบปัจจุบัน')}</span>
                    <span className="text-4xl font-black italic uppercase tracking-tighter">
                      {format(selectedDate, 'EEEE', { locale: dateLocale })}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-cyber-blue">{totalTasks}</div>
                    <div className="text-[8px] font-mono text-white/20 uppercase">{t('Active_Tasks', 'งานที่กำลังทำ')}</div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="h-1.5 bg-white/5 w-full relative overflow-hidden">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-cyber-blue to-electric-purple shadow-[0_0_15px_rgba(0,240,255,0.5)]"
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min((totalTasks / 8) * 100, 100)}%` }}
                      transition={{ duration: 1.5, ease: "circOut" }}
                    />
                  </div>
                  <div className="flex justify-between text-[8px] font-mono text-white/30 uppercase tracking-[0.2em]">
                    <span>{t('SYSTEM_LOAD', 'ภาระระบบ')}</span>
                    <span>{Math.round(Math.min((totalTasks / 8) * 100, 100))}%</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                <div className="space-y-1">
                  <div className="text-[8px] font-mono text-white/20 uppercase">{t('Efficiency', 'ประสิทธิภาพ')}</div>
                  <div className="text-lg font-black text-matrix-green">98.4%</div>
                </div>
                <div className="space-y-1 text-right">
                  <div className="text-[8px] font-mono text-white/20 uppercase">{t('Uptime', 'เวลาทำงาน')}</div>
                  <div className="text-lg font-black text-hot-pink">99.9%</div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.button
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            whileHover={{ scale: 1.02, x: 5 }}
            whileTap={{ scale: 0.98 }}
            onClick={openNewTaskModal}
            className="w-full bg-white text-black font-black py-8 text-4xl italic uppercase tracking-tighter hover:bg-cyber-blue transition-all shadow-[12px_12px_0px_0px_rgba(0,240,255,1)] hover:shadow-none hover:translate-x-2 hover:translate-y-2 flex items-center justify-center gap-6 relative overflow-hidden group"
          >
            <Plus size={40} className="group-hover:rotate-90 transition-transform duration-500" />
            <span className="relative z-10">{t('INITIALIZE', 'เริ่มภารกิจ')}</span>
          </motion.button>

          <div className="hidden lg:block space-y-8 pt-12 border-t border-white/5">
            <div className="flex items-center gap-3 text-[10px] font-mono uppercase tracking-[0.4em] text-white/20">
              <Cpu size={14} className="animate-spin-slow" /> 
              {t('DIAGNOSTIC_FEED', 'ข้อมูลวินิจฉัย')}
            </div>
            <div className="grid grid-cols-2 gap-6 text-[9px] font-mono text-white/20 uppercase leading-relaxed tracking-widest">
              <div className="space-y-2">
                <div className="flex items-center gap-2"><div className="w-1 h-1 bg-cyber-blue" /> OS: CHRONOS_v2</div>
                <div className="flex items-center gap-2"><div className="w-1 h-1 bg-cyber-blue" /> UI: {theme.toUpperCase()}</div>
                <div className="flex items-center gap-2"><div className="w-1 h-1 bg-cyber-blue" /> LOC: {Intl.DateTimeFormat().resolvedOptions().timeZone}</div>
              </div>
              <div className="space-y-2 text-right">
                <div>{t('LATENCY', 'ความหน่วง')}: 0.002MS</div>
                <div>{t('BUFFER', 'บัฟเฟอร์')}: STABLE</div>
                <div className="text-matrix-green">SYNC: ACTIVE</div>
              </div>
            </div>
          </div>
        </aside>

        {/* Schedule Grid Container */}
        <motion.div 
          initial={{ scale: 0.98, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ delay: 0.4, type: "spring", damping: 25 }}
          className="flex-1 flex flex-col min-h-[900px] border-2 border-white/5 bg-black/40 backdrop-blur-sm relative overflow-hidden"
        >
          {/* Decorative Grid Accents */}
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-white/20" />
          <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-white/20" />
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-white/20" />
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-white/20" />
          
          <ScheduleGrid 
            tasks={tasks} 
            selectedDate={selectedDate} 
            onEditTask={openEditTaskModal}
            language={language}
          />
        </motion.div>
      </main>

      {/* Modals & AI */}
      <AnimatePresence>
        {isModalOpen && (
          <TaskModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            onSave={handleSaveTask}
            onDelete={deleteTask}
            initialTask={editingTask}
            selectedDate={selectedDate}
            language={language}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isCalendarOpen && (
          <CalendarPicker
            isOpen={isCalendarOpen}
            onClose={() => setIsCalendarOpen(false)}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
            language={language}
          />
        )}
      </AnimatePresence>

      <ThemeCustomizer
        isOpen={isThemeOpen}
        onClose={() => setIsThemeOpen(false)}
        currentTheme={theme}
        onThemeChange={setTheme}
        currentLanguage={language}
        onLanguageChange={setLanguage}
        onLogout={logout}
        userEmail={user.email}
      />

      <AIScheduler tasks={tasks} onAddTask={addTask} language={language} />

      {/* Background Decorative Elements */}
      <div className="fixed inset-0 -z-20 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-5%] w-[50%] h-[50%] bg-cyber-blue/5 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-5%] w-[50%] h-[50%] bg-electric-purple/5 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
        
        {/* Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_80%)]" />
      </div>
    </div>
  );
}
