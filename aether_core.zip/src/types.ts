import { format } from 'date-fns';

export type RecurrenceType = 'once' | 'daily' | 'weekly' | 'weekdays';
export type TaskPriority = 'low' | 'medium' | 'high' | 'critical';
export type Language = 'en' | 'th';
export type ThemeType = 'cyberpunk' | 'minimal' | 'monochrome' | 'neon';

export interface UserProfile {
  uid: string;
  theme: ThemeType;
  language: Language;
}

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface ScheduleTask {
  id: string;
  title: string;
  description?: string;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  color: string;
  recurrence: RecurrenceType;
  priority: TaskPriority;
  status: 'pending' | 'completed' | 'skipped';
  subTasks: SubTask[];
  date?: string;     // YYYY-MM-DD (for 'once')
  daysOfWeek?: number[]; // 0-6 (for 'weekly')
}

export const PRIORITY_COLORS = {
  low: '#00FF66',
  medium: '#FFE600',
  high: '#FF3E00',
  critical: '#FF00D6',
};

export const COLORS = [
  '#FF3E00', // Neon Orange
  '#00F0FF', // Cyber Blue
  '#AD00FF', // Electric Purple
  '#00FF66', // Matrix Green
  '#FF00D6', // Hot Pink
  '#FFE600', // Warning Yellow
];

export const RECURRENCE_OPTIONS: { value: RecurrenceType; label: string; thLabel: string }[] = [
  { value: 'once', label: 'Only Today', thLabel: 'เฉพาะวันนี้' },
  { value: 'daily', label: 'Every Day', thLabel: 'ทุกวัน' },
  { value: 'weekly', label: 'Weekly', thLabel: 'รายสัปดาห์' },
  { value: 'weekdays', label: 'Mon - Fri', thLabel: 'จันทร์ - ศุกร์' },
];
