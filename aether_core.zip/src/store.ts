import { useState, useEffect } from 'react';
import { onAuthStateChanged, User, signInWithPopup, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { onSnapshot, collection, query, where, doc, setDoc, updateDoc, deleteDoc, Timestamp, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';
import { ScheduleTask, Language, ThemeType, UserProfile } from './types';

export function useScheduleStore() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [tasks, setTasks] = useState<ScheduleTask[]>([]);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthReady(true);
      if (!u) {
        setProfile(null);
        setTasks([]);
        setIsDataLoaded(true);
      }
    });
    return unsubscribe;
  }, []);

  // Profile & Tasks Listener
  useEffect(() => {
    if (!isAuthReady || !user) return;

    // Profile listener
    const profileRef = doc(db, 'users', user.uid);
    const unsubProfile = onSnapshot(profileRef, (snap) => {
      if (snap.exists()) {
        setProfile({ uid: user.uid, ...snap.data() } as UserProfile);
      } else {
        // Initialize profile if not exists
        const newProfile: Omit<UserProfile, 'uid'> = {
          theme: 'cyberpunk',
          language: 'en'
        };
        setDoc(profileRef, newProfile).catch(e => handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`));
      }
    }, (e) => handleFirestoreError(e, OperationType.GET, `users/${user.uid}`));

    // Tasks listener
    const tasksQuery = query(collection(db, 'tasks'), where('uid', '==', user.uid));
    const unsubTasks = onSnapshot(tasksQuery, (snap) => {
      const taskList: ScheduleTask[] = [];
      snap.forEach((d) => {
        const data = d.data();
        taskList.push({
          ...data,
          id: d.id,
        } as ScheduleTask);
      });
      setTasks(taskList);
      setIsDataLoaded(true);
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'tasks'));

    return () => {
      unsubProfile();
      unsubTasks();
    };
  }, [isAuthReady, user]);

  const login = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      console.error('Login failed', e);
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (e: any) {
      console.error('Email login failed', e);
      throw e;
    }
  };

  const registerWithEmail = async (email: string, pass: string) => {
    try {
      await createUserWithEmailAndPassword(auth, email, pass);
    } catch (e: any) {
      console.error('Email registration failed', e);
      throw e;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Logout failed', e);
    }
  };

  const sanitizeData = (data: any) => {
    const sanitized = { ...data };
    Object.keys(sanitized).forEach(key => {
      if (sanitized[key] === undefined || sanitized[key] === null) {
        delete sanitized[key];
      }
    });
    return sanitized;
  };

  const addTask = async (task: Omit<ScheduleTask, 'id'>) => {
    if (!user) return;
    const taskRef = doc(collection(db, 'tasks'));
    try {
      await setDoc(taskRef, sanitizeData({
        ...task,
        uid: user.uid,
        createdAt: Timestamp.now()
      }));
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'tasks');
    }
  };

  const updateTask = async (task: ScheduleTask) => {
    if (!user) return;
    const taskRef = doc(db, 'tasks', task.id);
    try {
      const { id, ...data } = task;
      await updateDoc(taskRef, sanitizeData({ ...data }));
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `tasks/${task.id}`);
    }
  };

  const deleteTask = async (id: string) => {
    if (!user) return;
    const taskRef = doc(db, 'tasks', id);
    try {
      await deleteDoc(taskRef);
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `tasks/${id}`);
    }
  };

  const setTheme = async (theme: ThemeType) => {
    if (!user) return;
    const profileRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(profileRef, { theme });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const setLanguage = async (language: Language) => {
    if (!user) return;
    const profileRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(profileRef, { language });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  return {
    user,
    profile,
    tasks,
    isLoaded: isAuthReady && isDataLoaded,
    login,
    loginWithEmail,
    registerWithEmail,
    logout,
    addTask,
    updateTask,
    deleteTask,
    setTheme,
    setLanguage
  };
}
