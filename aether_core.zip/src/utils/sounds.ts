/**
 * Simple Web Audio API based sound generator for UI feedback.
 * Designed to be "techy" and non-intrusive.
 */

class SoundManager {
  private audioCtx: AudioContext | null = null;

  private init() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  /**
   * Plays a light wood "tap".
   */
  playBlip() {
    this.init();
    if (!this.audioCtx) return;

    const now = this.audioCtx.currentTime;
    
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.exponentialRampToValueAtTime(200, now + 0.05);
    
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(now);
    osc.stop(now + 0.05);
  }

  /**
   * Plays a single solid "Thud" (ตึบ).
   */
  playClick() {
    this.init();
    if (!this.audioCtx) return;

    const now = this.audioCtx.currentTime;
    
    // Layer 1: Low frequency body
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.15);
    
    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    // Layer 2: Subtle noise click for tactility
    const bufferSize = this.audioCtx.sampleRate * 0.01;
    const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.audioCtx.createBufferSource();
    noise.buffer = buffer;
    const noiseGain = this.audioCtx.createGain();
    noiseGain.gain.setValueAtTime(0.05, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.01);
    
    noise.connect(noiseGain);
    noiseGain.connect(this.audioCtx.destination);

    osc.start(now);
    noise.start(now);
    osc.stop(now + 0.15);
  }

  /**
   * Plays a subtle digital "Whoosh" (วืบ) - softened.
   */
  playTransition() {
    this.init();
    if (!this.audioCtx) return;

    const now = this.audioCtx.currentTime;
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();
    const filter = this.audioCtx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(40, now);
    osc.frequency.exponentialRampToValueAtTime(300, now + 0.25);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(60, now);
    filter.frequency.exponentialRampToValueAtTime(800, now + 0.25);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.025, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  /**
   * Plays a sequence of wood hits as a success chime - DISABLED by user request.
   */
  playSuccess() {
    // No sound on completion as requested
  }

  /**
   * Plays a startup sound effect (digital sequence).
   */
  playStartup() {
    this.init();
    if (!this.audioCtx) return;

    const now = this.audioCtx.currentTime;
    const notes = [220, 440, 880, 1760]; // A3, A4, A5, A6
    
    notes.forEach((freq, i) => {
      const osc = this.audioCtx!.createOscillator();
      const gain = this.audioCtx!.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.1);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + i * 0.1 + 0.05);
      
      gain.gain.setValueAtTime(0, now + i * 0.1);
      gain.gain.linearRampToValueAtTime(0.1, now + i * 0.1 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.1);
      
      osc.connect(gain);
      gain.connect(this.audioCtx!.destination);
      
      osc.start(now + i * 0.1);
      osc.stop(now + i * 0.1 + 0.1);
    });
  }

  /**
   * Plays a cool, digital "Save" sound effect (rising sequence with resonance).
   */
  playSave() {
    this.init();
    if (!this.audioCtx) return;

    const now = this.audioCtx.currentTime;
    const duration = 0.4;
    
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();
    const filter = this.audioCtx.createBiquadFilter();

    osc.type = 'square';
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.exponentialRampToValueAtTime(800, now + duration);

    filter.type = 'lowpass';
    filter.Q.setValueAtTime(15, now);
    filter.frequency.setValueAtTime(400, now);
    filter.frequency.exponentialRampToValueAtTime(2000, now + duration);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.05, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(now);
    osc.stop(now + duration);
  }

  private musicNodes: AudioNode[] = [];
  private isMusicPlaying = false;

  /**
   * Starts a cool, ambient background loop.
   */
  startAmbientMusic() {
    this.init();
    if (!this.audioCtx || this.isMusicPlaying) return;
    this.isMusicPlaying = true;

    const now = this.audioCtx.currentTime;
    const masterGain = this.audioCtx.createGain();
    masterGain.gain.setValueAtTime(0.04, now); // Louder as requested
    masterGain.connect(this.audioCtx.destination);
    this.musicNodes.push(masterGain);

    // Deep drone
    const drone = this.audioCtx.createOscillator();
    drone.type = 'sine';
    drone.frequency.setValueAtTime(55, now); // A1
    drone.connect(masterGain);
    drone.start();
    this.musicNodes.push(drone);

    // Filtered noise for "atmosphere"
    const bufferSize = this.audioCtx.sampleRate * 2;
    const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

    const noise = this.audioCtx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;

    const noiseFilter = this.audioCtx.createBiquadFilter();
    noiseFilter.type = 'lowpass';
    noiseFilter.frequency.setValueAtTime(300, now);
    
    // Subtle LFO for filter
    const lfo = this.audioCtx.createOscillator();
    lfo.frequency.setValueAtTime(0.08, now);
    const lfoGain = this.audioCtx.createGain();
    lfoGain.gain.setValueAtTime(150, now);
    lfo.connect(lfoGain);
    lfoGain.connect(noiseFilter.frequency);
    lfo.start();

    noise.connect(noiseFilter);
    noiseFilter.connect(masterGain);
    noise.start();
    
    this.musicNodes.push(noise, lfo, noiseFilter);
  }

  stopAmbientMusic() {
    this.musicNodes.forEach(node => {
      try { (node as any).stop?.(); } catch(e) {}
      node.disconnect();
    });
    this.musicNodes = [];
    this.isMusicPlaying = false;
  }
}

export const sounds = new SoundManager();
