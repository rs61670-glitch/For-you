import React, { useMemo, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import { ScheduleTask, PRIORITY_COLORS, Language } from '../types';
import { Clock, CheckCircle2 } from 'lucide-react';
import { sounds } from '../utils/sounds';

interface ScheduleGridProps {
  tasks: ScheduleTask[];
  selectedDate: Date;
  onEditTask: (task: ScheduleTask) => void;
  language: Language;
}

interface PositionedTask extends ScheduleTask {
  column: number;
  totalColumns: number;
}

export default function ScheduleGrid({ tasks, selectedDate, onEditTask, language }: ScheduleGridProps) {
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const [now, setNow] = useState(new Date());
  const isToday = format(selectedDate, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  const nowPosition = ((currentHour + currentMinute / 60) / 24) * 100;

  const positionedTasks = useMemo(() => {
    const filtered = tasks.filter((task) => {
      if (task.recurrence === 'once') return task.date === format(selectedDate, 'yyyy-MM-dd');
      if (task.recurrence === 'daily') return true;
      if (task.recurrence === 'weekly') return task.daysOfWeek?.includes(selectedDate.getDay());
      if (task.recurrence === 'weekdays') {
        const day = selectedDate.getDay();
        return day >= 1 && day <= 5;
      }
      return false;
    }).sort((a, b) => a.startTime.localeCompare(b.startTime));

    // Overlap detection algorithm
    const result: PositionedTask[] = [];

    // Assign column info
    const groups: ScheduleTask[][] = [];
    filtered.forEach(task => {
      let addedToGroup = false;
      for (const group of groups) {
        if (group.some(t => (task.startTime < t.endTime && task.endTime > t.startTime))) {
          group.push(task);
          addedToGroup = true;
          break;
        }
      }
      if (!addedToGroup) groups.push([task]);
    });

    filtered.forEach(task => {
      const group = groups.find(g => g.includes(task)) || [task];
      const sortedGroup = [...group].sort((a, b) => a.startTime.localeCompare(b.startTime));
      const colIndex = sortedGroup.indexOf(task);
      result.push({
        ...task,
        column: colIndex,
        totalColumns: group.length
      });
    });

    return result;
  }, [tasks, selectedDate]);

  const getTaskPosition = (startTime: string, endTime: string, column: number, totalColumns: number) => {
    const [startH, startM] = startTime.split(':').map(Number);
    const [endH, endM] = endTime.split(':').map(Number);
    
    const startPos = startH * 60 + startM;
    const endPos = endH * 60 + endM;
    const duration = Math.max(endPos - startPos, 60); // Increased min duration for visibility

    const width = 100 / totalColumns;
    const left = width * column;

    return {
      top: `${(startPos / (24 * 60)) * 100}%`,
      height: `${(duration / (24 * 60)) * 100}%`,
      width: `${width}%`,
      left: `${left}%`,
    };
  };

  const handleTaskClick = (task: ScheduleTask) => {
    sounds.startAmbientMusic();
    sounds.playClick();
    onEditTask(task);
  };

  return (
    <div className="relative flex-1 bg-[#050505] border-2 border-white/5 overflow-y-auto custom-scrollbar group selection:bg-cyber-blue selection:text-black">
      {/* Grid Lines */}
      <div className="absolute inset-0 pointer-events-none min-h-[2400px]">
        {hours.map((h) => (
          <div
            key={h}
            className="absolute w-full border-t border-white/[0.02] flex items-start px-4 group/line"
            style={{ top: `${(h / 24) * 100}%` }}
          >
            <div className="flex items-center gap-3 -translate-y-1/2 bg-[#050505] px-2 py-1 border border-white/5 shadow-[0_0_10px_rgba(255,255,255,0.02)] group-hover/line:border-cyber-blue/40 transition-all duration-500">
              <div className="flex flex-col items-center">
                <span className="text-[7px] font-mono text-white/20 uppercase tracking-widest leading-none mb-1">TIME_SYNC</span>
                <span className="text-sm font-mono text-white/40 font-black tracking-widest group-hover/line:text-cyber-blue transition-colors duration-500 drop-shadow-[0_0_5px_rgba(0,240,255,0.2)]">
                  {h.toString().padStart(2, '0')}:00
                </span>
              </div>
            </div>
          </div>
        ))}

        {/* Current Time Indicator - Consolidated */}
        {isToday && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute w-full z-20 pointer-events-none"
            style={{ top: `${nowPosition}%` }}
          >
            <div className="relative flex items-center">
              <div className="absolute left-0 -translate-y-1/2 bg-cyber-blue text-black font-mono text-[9px] font-black px-3 py-1 tracking-widest shadow-[0_0_20px_rgba(0,240,255,0.6)] flex items-center gap-2">
                <div className="w-1 h-1 bg-black animate-pulse" />
                {language === 'th' ? 'เวลา_ปัจจุบัน' : 'NOW_SYNC'}: {format(now, 'HH:mm')}
              </div>
              <div className="w-full h-[2px] bg-cyber-blue shadow-[0_0_15px_rgba(0,240,255,0.5)]" />
              <div className="absolute right-0 w-3 h-3 bg-cyber-blue rounded-full blur-[3px] animate-pulse" />
            </div>
          </motion.div>
        )}
      </div>

      {/* Tasks Container */}
      <div className="absolute inset-0 ml-28 mr-4 min-h-[2400px]">
        {positionedTasks.map((task, idx) => {
          const pos = getTaskPosition(task.startTime, task.endTime, task.column, task.totalColumns);
          const completedSubtasks = task.subTasks?.filter(st => st.completed).length || 0;
          const totalSubtasks = task.subTasks?.length || 0;
          const progress = totalSubtasks > 0 ? (completedSubtasks / totalSubtasks) * 100 : 0;

          return (
            <motion.div
              key={task.id}
              initial={{ opacity: 0, x: -20, scale: 0.95, filter: 'blur(10px)' }}
              animate={{ opacity: 1, x: 0, scale: 1, filter: 'blur(0px)' }}
              whileHover={{ scale: 1.02, zIndex: 50, rotate: 0.5 }}
              whileTap={{ scale: 0.98 }}
              transition={{ 
                type: "spring",
                stiffness: 400,
                damping: 15,
                delay: idx * 0.02 
              }}
              onClick={() => handleTaskClick(task)}
              className="absolute p-1 cursor-pointer group/task"
              style={{ ...pos }}
            >
              <div 
                className={`h-full w-full p-4 md:p-6 border-l-4 overflow-hidden relative transition-all duration-500 ${
                  task.status === 'completed' ? 'opacity-50 grayscale-[0.5]' : 'opacity-100'
                } group-hover/task:shadow-[0_0_40px_-5px_var(--task-color)] group-hover/task:border-l-8`}
                style={{ 
                  '--task-color': task.color,
                  backgroundColor: `${task.color}15`,
                  borderColor: task.color,
                  backdropFilter: 'blur(12px)',
                } as React.CSSProperties}
              >
                {/* Background Pattern */}
                <div className="absolute inset-0 opacity-10 pointer-events-none" 
                  style={{ backgroundImage: `repeating-linear-gradient(45deg, ${task.color}, ${task.color} 1px, transparent 1px, transparent 15px)` }} 
                />
                
                {/* Corner Accents */}
                <div className="absolute top-0 right-0 w-4 h-4 border-t border-r border-white/10" />
                <div className="absolute bottom-0 left-0 w-4 h-4 border-b border-l border-white/10" />

                {/* Priority Glow */}
                <div 
                  className="absolute top-0 right-0 w-24 h-24 opacity-30 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2 animate-pulse"
                  style={{ backgroundColor: PRIORITY_COLORS[task.priority] }}
                />

                <div className="flex flex-col h-full relative z-10">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex flex-col gap-1.5 w-full">
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] font-mono uppercase tracking-[0.3em] text-cyber-blue font-black drop-shadow-[0_0_8px_rgba(0,240,255,0.5)]">
                          {task.startTime} — {task.endTime}
                        </span>
                        {task.recurrence !== 'once' && (
                          <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest border border-white/20 px-1.5 py-0.5 bg-black/20 rounded-sm">
                            {task.recurrence}
                          </span>
                        )}
                      </div>
                      <div className="relative">
                        <div className="absolute -inset-2 bg-black/60 blur-lg rounded-lg -z-10" />
                        <h3 className="font-black text-xl md:text-3xl uppercase tracking-tighter leading-[0.9] text-white transition-colors break-words drop-shadow-[0_4px_12px_rgba(0,0,0,1)]">
                          {task.title}
                        </h3>
                      </div>
                    </div>
                    <div className={`
                      px-2 py-1 bg-black/60 text-[9px] font-black uppercase tracking-[0.2em] border backdrop-blur-md shrink-0 rounded-sm
                      ${task.priority === 'critical' ? 'text-red-500 border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.4)]' : 
                        task.priority === 'high' ? 'text-orange-500 border-orange-500/50' : 
                        task.priority === 'medium' ? 'text-yellow-500 border-yellow-500/50' : 
                        'text-blue-500 border-blue-500/50'}
                    `}>
                      {task.priority}
                    </div>
                  </div>
                  
                  {task.description && (
                    <p className="mt-3 text-[11px] font-bold text-white/80 line-clamp-2 leading-tight uppercase tracking-wider break-words drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                      {task.description}
                    </p>
                  )}
                  
                  {totalSubtasks > 0 && (
                    <div className="mt-auto pt-4">
                      <div className="flex justify-between items-end mb-1">
                        <div className="flex items-center gap-2">
                          <div className="w-1 h-1 bg-cyber-blue animate-pulse" />
                          <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest">
                            {language === 'th' ? 'สถานะ_โปรโตคอล' : 'Sub_Protocol_Sync'}
                          </span>
                        </div>
                        <span className="text-[9px] font-mono text-cyber-blue font-black">{Math.round(progress)}%</span>
                      </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden border border-white/5">
                        <motion.div 
                          className="h-full shadow-[0_0_15px_var(--task-color)]"
                          style={{ backgroundColor: task.color, '--task-color': task.color } as any}
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-1.5 h-1.5 rounded-full ${task.status === 'completed' ? 'bg-matrix-green shadow-[0_0_10px_#00FF41]' : 'bg-white/10'}`} />
                      <span className="text-[8px] font-mono uppercase tracking-[0.2em] text-white/20 font-black">
                        {task.status === 'completed' 
                          ? (language === 'th' ? 'เสร็จสิ้น_ภารกิจ' : 'EXECUTION_COMPLETE') 
                          : (language === 'th' ? 'รอ_การกระตุ้น' : 'AWAITING_TRIGGER')}
                      </span>
                    </div>
                    {task.status === 'completed' && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-matrix-green"
                      >
                        <CheckCircle2 size={14} />
                      </motion.div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
