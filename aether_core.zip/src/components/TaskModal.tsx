import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Clock, Repeat, Trash2, CheckCircle2, ListTodo, AlertTriangle, ChevronRight, Activity, Zap, Save, AlignLeft } from 'lucide-react';
import { ScheduleTask, COLORS, RECURRENCE_OPTIONS, RecurrenceType, TaskPriority, SubTask, PRIORITY_COLORS, Language } from '../types';
import { format } from 'date-fns';
import { sounds } from '../utils/sounds';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: ScheduleTask) => void;
  onDelete?: (id: string) => void;
  initialTask?: ScheduleTask | null;
  selectedDate: Date;
  language: Language;
}

export default function TaskModal({ isOpen, onClose, onSave, onDelete, initialTask, selectedDate, language }: TaskModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [color, setColor] = useState(COLORS[0]);
  const [recurrence, setRecurrence] = useState<RecurrenceType>('once');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [subTasks, setSubTasks] = useState<SubTask[]>([]);
  const [newSubTask, setNewSubTask] = useState('');
  const [showTimePicker, setShowTimePicker] = useState<'start' | 'end' | null>(null);

  const t = (en: string, th: string) => language === 'th' ? th : en;

  useEffect(() => {
    if (initialTask) {
      setTitle(initialTask.title);
      setDescription(initialTask.description || '');
      setStartTime(initialTask.startTime);
      setEndTime(initialTask.endTime);
      setColor(initialTask.color);
      setRecurrence(initialTask.recurrence);
      setPriority(initialTask.priority || 'medium');
      setSubTasks(initialTask.subTasks || []);
    } else {
      const now = new Date();
      const startH = now.getHours().toString().padStart(2, '0');
      const startM = (Math.ceil(now.getMinutes() / 15) * 15 % 60).toString().padStart(2, '0');
      const endH = ((now.getHours() + 1) % 24).toString().padStart(2, '0');
      
      setTitle('');
      setDescription('');
      setStartTime(`${startH}:${startM}`);
      setEndTime(`${endH}:${startM}`);
      setColor(COLORS[0]);
      setRecurrence('once');
      setPriority('medium');
      setSubTasks([]);
    }
  }, [initialTask, isOpen]);

  const handleTimeSelect = (type: 'start' | 'end', h: string, m: string) => {
    sounds.playBlip();
    const timeStr = `${h}:${m}`;
    if (type === 'start') {
      setStartTime(timeStr);
      const [sh, sm] = timeStr.split(':').map(Number);
      const [eh, em] = endTime.split(':').map(Number);
      if (eh < sh || (eh === sh && em <= sm)) {
        setEndTime(`${((sh + 1) % 24).toString().padStart(2, '0')}:${sm.toString().padStart(2, '0')}`);
      }
    } else {
      setEndTime(timeStr);
    }
    setShowTimePicker(null);
  };

  const handleSave = () => {
    if (!title) return;
    onSave({
      id: initialTask?.id || Math.random().toString(36).substr(2, 9),
      title,
      description,
      startTime,
      endTime,
      color,
      recurrence,
      priority,
      status: initialTask?.status || 'pending',
      subTasks,
      date: recurrence === 'once' ? format(selectedDate, 'yyyy-MM-dd') : null,
      daysOfWeek: recurrence === 'weekly' ? [selectedDate.getDay()] : null,
    });
    onClose();
  };

  const addSubTask = () => {
    if (!newSubTask.trim()) return;
    sounds.playClick();
    setSubTasks([...subTasks, { id: Date.now().toString(), title: newSubTask, completed: false }]);
    setNewSubTask('');
  };

  const toggleSubTask = (id: string) => {
    sounds.playBlip();
    setSubTasks(subTasks.map(st => st.id === id ? { ...st, completed: !st.completed } : st));
  };

  const removeSubTask = (id: string) => {
    sounds.playClick();
    setSubTasks(subTasks.filter(st => st.id !== id));
  };

  const handleClose = () => {
    sounds.playClick();
    onClose();
  };

  const isNewTask = !initialTask;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="absolute inset-0 bg-black/90 backdrop-blur-md"
          />
          <motion.div
            initial={isNewTask ? { y: '100%' } : { scale: 0.9, opacity: 0 }}
            animate={isNewTask ? { y: 0 } : { scale: 1, opacity: 1 }}
            exit={isNewTask ? { y: '100%' } : { scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className={`relative w-full bg-[#0A0A0A] border-white/10 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,1)] flex flex-col ${
              isNewTask 
                ? 'h-full max-w-none border-0' 
                : 'max-w-xl max-h-[85vh] border rounded-2xl'
            }`}
          >
            {/* Header */}
            <div className={`p-6 border-b border-white/10 flex justify-between items-center bg-white/[0.02] ${isNewTask ? 'pt-12 md:pt-6' : ''}`}>
              <div className="flex items-center gap-4">
                <div className="w-2 h-8 bg-cyber-blue rounded-full" style={{ backgroundColor: color }} />
                <div>
                  <div className="text-[10px] font-mono text-white/20 uppercase tracking-[0.4em]">
                    {isNewTask ? t('TASK_INITIALIZATION', 'การเริ่มภารกิจ') : t('TASK_DETAIL', 'รายละเอียดภารกิจ')}
                  </div>
                  <h2 className={`${isNewTask ? 'text-4xl' : 'text-xl'} font-black italic uppercase tracking-tighter text-white`}>
                    {isNewTask ? t('New_Task', 'งานใหม่') : t('View_Task', 'ดูรายละเอียด')}
                  </h2>
                </div>
              </div>
              <button 
                onClick={handleClose}
                className="p-3 hover:bg-white/10 transition-colors text-white/40 hover:text-white rounded-full"
              >
                <X size={isNewTask ? 32 : 20} />
              </button>
            </div>

            <div className={`flex-1 overflow-y-auto custom-scrollbar p-6 md:p-10 space-y-10 ${isNewTask ? 'max-w-4xl mx-auto w-full' : ''}`}>
              {/* Title Input */}
              <div className="space-y-4">
                <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                  <Activity size={12} className="text-cyber-blue" /> {t('OBJECTIVE', 'เป้าหมาย')}
                </label>
                <input
                  autoFocus
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className={`w-full bg-white/[0.03] border border-white/10 p-5 font-black uppercase tracking-tighter focus:border-cyber-blue outline-none transition-all text-white placeholder:text-white/5 rounded-xl ${
                    isNewTask ? 'text-4xl md:text-6xl' : 'text-xl'
                  }`}
                  placeholder={t('ENTER_TASK_NAME...', 'ระบุชื่องาน...')}
                />
              </div>

              {/* Description Input */}
              <div className="space-y-4">
                <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                  <AlignLeft size={12} className="text-cyber-blue" /> {t('DESCRIPTION', 'รายละเอียด')}
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={isNewTask ? 4 : 2}
                  className="w-full bg-white/[0.03] border border-white/10 p-5 font-mono text-sm tracking-wide focus:border-cyber-blue outline-none transition-all text-white/70 placeholder:text-white/5 rounded-xl resize-none"
                  placeholder={t('ADD_DETAILS_HERE...', 'เพิ่มรายละเอียดที่นี่...')}
                />
              </div>

              <div className={`grid gap-10 ${isNewTask ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
                <div className="space-y-10">
                  {/* Time Selection */}
                  <div className="space-y-4">
                    <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                      <Clock size={12} className="text-cyber-blue" /> {t('TIME', 'เวลา')}
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2 relative">
                        <span className="text-[8px] font-mono text-white/20 uppercase">{t('START', 'เริ่ม')}</span>
                        <button
                          onClick={() => setShowTimePicker(showTimePicker === 'start' ? null : 'start')}
                          className="w-full bg-white/[0.03] border border-white/10 p-4 font-mono text-lg focus:border-cyber-blue outline-none transition-all text-white/80 rounded-lg text-left flex justify-between items-center"
                        >
                          {startTime}
                          <Clock size={14} className="text-cyber-blue opacity-50" />
                        </button>
                        {showTimePicker === 'start' && (
                          <div className="absolute z-50 mt-2 p-4 bg-[#151515] border border-white/10 rounded-2xl shadow-2xl w-64 left-0">
                            <div className="grid grid-cols-4 gap-2 mb-4 max-h-40 overflow-y-auto custom-scrollbar p-1">
                              {Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0')).map(hour => (
                                <button
                                  key={hour}
                                  onClick={() => handleTimeSelect('start', hour, startTime.split(':')[1])}
                                  className={`p-2 text-[10px] font-mono rounded-lg transition-all ${
                                    startTime.split(':')[0] === hour ? 'bg-cyber-blue text-black' : 'hover:bg-white/5 text-white/40'
                                  }`}
                                >
                                  {hour}
                                </button>
                              ))}
                            </div>
                            <div className="h-[1px] bg-white/5 mb-4" />
                            <div className="grid grid-cols-4 gap-2">
                              {['00', '15', '30', '45'].map(min => (
                                <button
                                  key={min}
                                  onClick={() => handleTimeSelect('start', startTime.split(':')[0], min)}
                                  className={`p-2 text-[10px] font-mono rounded-lg transition-all ${
                                    startTime.split(':')[1] === min ? 'bg-cyber-blue text-black' : 'hover:bg-white/5 text-white/40'
                                  }`}
                                >
                                  {min}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="space-y-2 relative">
                        <span className="text-[8px] font-mono text-white/20 uppercase">{t('END', 'จบ')}</span>
                        <button
                          onClick={() => setShowTimePicker(showTimePicker === 'end' ? null : 'end')}
                          className="w-full bg-white/[0.03] border border-white/10 p-4 font-mono text-lg focus:border-cyber-blue outline-none transition-all text-white/80 rounded-lg text-left flex justify-between items-center"
                        >
                          {endTime}
                          <Clock size={14} className="text-cyber-blue opacity-50" />
                        </button>
                        {showTimePicker === 'end' && (
                          <div className="absolute z-50 mt-2 p-4 bg-[#151515] border border-white/10 rounded-2xl shadow-2xl w-64 right-0">
                            <div className="grid grid-cols-4 gap-2 mb-4 max-h-40 overflow-y-auto custom-scrollbar p-1">
                              {Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0')).map(hour => (
                                <button
                                  key={hour}
                                  onClick={() => handleTimeSelect('end', hour, endTime.split(':')[1])}
                                  className={`p-2 text-[10px] font-mono rounded-lg transition-all ${
                                    endTime.split(':')[0] === hour ? 'bg-cyber-blue text-black' : 'hover:bg-white/5 text-white/40'
                                  }`}
                                >
                                  {hour}
                                </button>
                              ))}
                            </div>
                            <div className="h-[1px] bg-white/5 mb-4" />
                            <div className="grid grid-cols-4 gap-2">
                              {['00', '15', '30', '45'].map(min => (
                                <button
                                  key={min}
                                  onClick={() => handleTimeSelect('end', endTime.split(':')[0], min)}
                                  className={`p-2 text-[10px] font-mono rounded-lg transition-all ${
                                    endTime.split(':')[1] === min ? 'bg-cyber-blue text-black' : 'hover:bg-white/5 text-white/40'
                                  }`}
                                >
                                  {min}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Priority Selection */}
                  <div className="space-y-4">
                    <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                      <AlertTriangle size={12} className="text-hot-pink" /> {t('PRIORITY', 'ความสำคัญ')}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {(['low', 'medium', 'high', 'critical'] as TaskPriority[]).map((p) => (
                        <button
                          key={p}
                          onClick={() => { sounds.playClick(); setPriority(p); }}
                          className={`px-4 py-4 text-[10px] font-black uppercase tracking-widest border transition-all rounded-lg ${
                            priority === p 
                              ? 'text-black border-transparent' 
                              : 'border-white/5 text-white/20 hover:border-white/20'
                          }`}
                          style={priority === p ? { backgroundColor: PRIORITY_COLORS[p] } : {}}
                        >
                          {language === 'th' ? (p === 'low' ? 'ต่ำ' : p === 'medium' ? 'กลาง' : p === 'high' ? 'สูง' : 'วิกฤต') : p}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-10">
                  {/* Recurrence */}
                  <div className="space-y-4">
                    <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                      <Repeat size={12} className="text-cyber-blue" /> {t('RECURRENCE', 'ทำซ้ำ')}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {RECURRENCE_OPTIONS.map((opt) => (
                        <button
                          key={opt.value}
                          onClick={() => { sounds.playClick(); setRecurrence(opt.value); }}
                          className={`px-4 py-4 text-[10px] font-black uppercase tracking-widest border transition-all rounded-lg ${
                            recurrence === opt.value
                              ? 'bg-white text-black border-white'
                              : 'bg-transparent text-white/20 border-white/5 hover:border-white/20'
                          }`}
                        >
                          {language === 'th' ? opt.thLabel : opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Selection */}
                  <div className="space-y-4">
                    <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                      <Zap size={12} className="text-cyber-blue" /> {t('COLOR', 'สี')}
                    </label>
                    <div className="flex flex-wrap gap-3">
                      {COLORS.map((c) => (
                        <button
                          key={c}
                          onClick={() => { sounds.playClick(); setColor(c); }}
                          className={`w-10 h-10 rounded-full transition-all ${
                            color === c ? 'ring-4 ring-white scale-110 shadow-[0_0_20px_var(--c)]' : 'opacity-30 hover:opacity-100'
                          }`}
                          style={{ backgroundColor: c, '--c': c } as any}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Subtasks */}
              <div className="space-y-6">
                <label className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] flex items-center gap-2">
                  <ListTodo size={12} className="text-matrix-green" /> {t('SUB_TASKS', 'งานย่อย')}
                </label>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={newSubTask}
                    onChange={(e) => setNewSubTask(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addSubTask()}
                    className="flex-1 bg-white/[0.03] border border-white/10 p-5 font-mono text-xs uppercase tracking-widest outline-none focus:border-cyber-blue rounded-xl"
                    placeholder={t('ADD_STEP...', 'เพิ่มขั้นตอน...')}
                  />
                  <button 
                    onClick={addSubTask}
                    className="bg-white/10 text-white px-8 hover:bg-white hover:text-black transition-all rounded-xl"
                  >
                    <Plus size={24} />
                  </button>
                </div>
                <div className={`space-y-2 pr-2 ${isNewTask ? '' : 'max-h-60 overflow-y-auto custom-scrollbar'}`}>
                  {subTasks.map((st) => (
                    <div 
                      key={st.id}
                      className="flex items-center gap-4 bg-white/[0.02] p-5 border border-white/5 group rounded-xl"
                    >
                      <button 
                        onClick={() => toggleSubTask(st.id)}
                        className={`transition-colors ${st.completed ? 'text-matrix-green' : 'text-white/10 hover:text-white/30'}`}
                      >
                        <CheckCircle2 size={24} />
                      </button>
                      <span className={`flex-1 text-xs font-mono uppercase tracking-widest ${st.completed ? 'opacity-20 line-through' : 'text-white/60'}`}>
                        {st.title}
                      </span>
                      <button 
                        onClick={() => removeSubTask(st.id)}
                        className="opacity-0 group-hover:opacity-100 text-white/20 hover:text-red-500 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className={`p-8 border-t border-white/10 flex gap-4 bg-white/[0.02] ${isNewTask ? 'pb-12 md:pb-8' : ''}`}>
              {initialTask && onDelete && (
                <button
                  onClick={() => {
                    sounds.playClick();
                    onDelete(initialTask.id);
                    onClose();
                  }}
                  className="px-8 py-5 border border-red-500/20 text-red-500 font-black uppercase tracking-widest text-[10px] hover:bg-red-500 hover:text-white transition-all rounded-xl"
                >
                  {t('DELETE', 'ลบ')}
                </button>
              )}
              <div className="flex-1" />
              <button
                onClick={handleClose}
                className="px-8 py-5 border border-white/10 text-white/40 font-black uppercase tracking-widest text-[10px] hover:text-white transition-all rounded-xl"
              >
                {t('CANCEL', 'ยกเลิก')}
              </button>
              <button
                onClick={handleSave}
                className="px-16 py-5 bg-white text-black font-black uppercase tracking-widest text-[10px] hover:bg-cyber-blue transition-all flex items-center gap-3 rounded-xl"
              >
                <Save size={18} />
                {t('SAVE', 'บันทึก')}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
