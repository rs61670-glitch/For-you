import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { Sparkles, Send, X, Bot, Loader2 } from 'lucide-react';
import { ScheduleTask, Language } from '../types';
import { sounds } from '../utils/sounds';

interface AISchedulerProps {
  tasks: ScheduleTask[];
  onAddTask: (task: ScheduleTask) => void;
  language: Language;
}

export default function AIScheduler({ tasks, onAddTask, language }: AISchedulerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const t = (en: string, th: string) => language === 'th' ? th : en;

  const handleOpen = () => {
    sounds.startAmbientMusic();
    sounds.playClick();
    setIsOpen(true);
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    sounds.startAmbientMusic();
    sounds.playClick();
    setIsLoading(true);
    setResponse('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `You are a high-performance schedule assistant. 
        The current tasks are: ${tasks.map(t => t.title).join(', ')}.
        User request: ${prompt}.
        Current language setting: ${language === 'th' ? 'Thai' : 'English'}.
        Provide a concise, motivating response in ${language === 'th' ? 'Thai' : 'English'} and suggest 1-2 new tasks if appropriate. 
        Format as a cool HUD message.`,
      });

      const result = await model;
      setResponse(result.text || 'No response generated.');
    } catch (error) {
      console.error('AI Error:', error);
      setResponse('ERROR: AI_CORE_OFFLINE. Please check connection.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={handleOpen}
        className="fixed bottom-8 right-8 w-16 h-16 bg-cyber-blue text-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.5)] hover:scale-110 transition-all z-40 group"
      >
        <Sparkles size={24} className="group-hover:rotate-12 transition-transform" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 100, x: 0 }}
            animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 100, x: 0 }}
            className="fixed bottom-28 right-8 w-full max-w-md bg-[#050505] border-2 border-cyber-blue p-8 shadow-[0_0_50px_rgba(0,240,255,0.1)] z-50 overflow-hidden"
          >
            {/* Background Decorative Elements */}
            <div className="absolute top-0 left-0 w-full h-1 bg-cyber-blue/20" />
            <div className="absolute inset-0 bg-[linear-gradient(rgba(0,240,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,240,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

            <div className="flex justify-between items-center mb-8 relative z-10">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-cyber-blue animate-pulse" />
                <div className="flex flex-col">
                  <span className="text-cyber-blue font-mono text-[10px] tracking-[0.4em] uppercase font-black">{t('AI_CORE_LINK', 'การเชื่อมต่อแกน AI')}</span>
                  <span className="text-white/20 font-mono text-[8px] uppercase">{t('Status: Connected_Secure', 'สถานะ: เชื่อมต่อปลอดภัย')}</span>
                </div>
              </div>
              <motion.button 
                whileHover={{ rotate: 90, scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsOpen(false)} 
                className="text-white/30 hover:text-white p-2 border border-white/10"
              >
                <X size={18} />
              </motion.button>
            </div>

            <div className="space-y-6 relative z-10">
              <div className="h-64 overflow-y-auto custom-scrollbar bg-black/50 p-5 border border-white/5 font-mono text-[11px] leading-relaxed relative group/terminal">
                {/* Terminal Scanline */}
                <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-cyber-blue/5 to-transparent h-8 animate-scanline-fast opacity-20" />
                
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center h-full gap-4">
                    <Loader2 size={32} className="animate-spin text-cyber-blue" />
                    <span className="text-cyber-blue/40 animate-pulse uppercase tracking-widest text-[10px]">Processing_Data...</span>
                  </div>
                ) : response ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-4"
                  >
                    <div className="flex items-center gap-2 text-cyber-blue/60">
                      <span className="text-[10px]">{">"}</span>
                      <span className="uppercase tracking-tighter font-black">{t('Response_Received:', 'ได้รับคำตอบ:')}</span>
                    </div>
                    <div className="text-white/80 whitespace-pre-wrap border-l-2 border-cyber-blue/20 pl-4 py-1">
                      {response}
                    </div>
                  </motion.div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full gap-2 text-center">
                    <Bot size={40} className="text-white/5" />
                    <div className="text-white/20 italic uppercase tracking-widest text-[9px]">
                      {t('Awaiting_Input_Sequence...', 'กำลังรอคำสั่ง...')}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <div className="flex-1 relative group">
                  <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleGenerate()}
                    placeholder={t('ENTER_COMMAND_SEQUENCE...', 'ป้อนลำดับคำสั่ง...')}
                    className="w-full bg-white/[0.02] border border-white/10 p-4 outline-none focus:border-cyber-blue focus:bg-cyber-blue/5 font-mono text-xs transition-all placeholder:text-white/10"
                  />
                  <div className="absolute bottom-0 left-0 h-[1px] bg-cyber-blue w-0 group-focus-within:w-full transition-all duration-500" />
                </div>
                <motion.button 
                  whileHover={{ scale: 1.05, backgroundColor: '#00F0FF' }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleGenerate}
                  disabled={isLoading}
                  className="bg-cyber-blue text-black px-6 font-black hover:bg-white transition-all disabled:opacity-50 flex items-center justify-center"
                >
                  <Send size={20} />
                </motion.button>
              </div>

              <div className="flex justify-between items-center px-1">
                <div className="flex gap-1">
                  <div className="w-1 h-1 bg-cyber-blue/40" />
                  <div className="w-1 h-1 bg-cyber-blue/40" />
                  <div className="w-1 h-1 bg-cyber-blue/40" />
                </div>
                <span className="text-[8px] font-mono text-white/10 uppercase tracking-[0.3em]">Neural_Link_v2.5</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
