import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, startOfWeek, endOfWeek } from 'date-fns';
import { th, enUS } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { Language } from '../types';
import { sounds } from '../utils/sounds';

interface CalendarPickerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: Date;
  onSelectDate: (date: Date) => void;
  language: Language;
}

export default function CalendarPicker({ isOpen, onClose, selectedDate, onSelectDate, language }: CalendarPickerProps) {
  const [viewDate, setViewDate] = React.useState(selectedDate);

  const t = (en: string, th: string) => language === 'th' ? th : en;
  const dateLocale = language === 'th' ? th : enUS;

  const days = React.useMemo(() => {
    const start = startOfWeek(startOfMonth(viewDate));
    const end = endOfWeek(endOfMonth(viewDate));
    return eachDayOfInterval({ start, end });
  }, [viewDate]);

  const handlePrevMonth = () => { sounds.playClick(); setViewDate(subMonths(viewDate, 1)); };
  const handleNextMonth = () => { sounds.playClick(); setViewDate(addMonths(viewDate, 1)); };

  const handleClose = () => {
    sounds.playClick();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="absolute inset-0 bg-black/90 backdrop-blur-md"
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0, rotateX: 45 }}
            animate={{ scale: 1, opacity: 1, rotateX: 0 }}
            exit={{ scale: 0.9, opacity: 0, rotateX: -45 }}
            style={{ perspective: '1000px' }}
            className="relative w-full max-w-md bg-[#050505] border-2 border-cyber-blue p-8 shadow-[0_0_60px_rgba(0,240,255,0.15)] overflow-hidden"
          >
            {/* Background Grid Accent */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,240,255,0.05),transparent)] pointer-events-none" />
            <div className="absolute top-0 right-0 p-2 text-[8px] font-mono text-cyber-blue/20 select-none">
              CAL_SYS_v4.2.0
            </div>

            <div className="flex justify-between items-end mb-10 relative z-10">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-[1px] bg-cyber-blue" />
                  <div className="text-[10px] font-mono text-cyber-blue uppercase tracking-[0.4em] font-black">{t('Temporal_Matrix', 'เมทริกซ์ทางเวลา')}</div>
                </div>
                <h3 className="text-4xl font-black italic uppercase tracking-tighter text-white leading-none">
                  {format(viewDate, 'MMMM', { locale: dateLocale })}
                  <span className="block text-sm font-mono text-white/30 not-italic tracking-[0.2em] mt-1">{t('YEAR', 'ปี')}_{format(viewDate, 'yyyy')}</span>
                </h3>
              </div>
              <div className="flex gap-3">
                <motion.button 
                  whileHover={{ scale: 1.1, backgroundColor: 'rgba(255,255,255,0.1)' }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handlePrevMonth} 
                  className="p-3 border border-white/10 text-white/50 hover:text-cyber-blue transition-colors"
                >
                  <ChevronLeft size={24} />
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.1, backgroundColor: 'rgba(255,255,255,0.1)' }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handleNextMonth} 
                  className="p-3 border border-white/10 text-white/50 hover:text-cyber-blue transition-colors"
                >
                  <ChevronRight size={24} />
                </motion.button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-2 mb-4 relative z-10">
              {(language === 'th' ? ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'] : ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']).map((d, i) => (
                <div key={i} className="text-center text-[9px] font-mono text-white/20 font-black tracking-widest">{d}</div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-2 relative z-10">
              {days.map((day, i) => {
                const isSelected = isSameDay(day, selectedDate);
                const isCurrentMonth = isSameMonth(day, viewDate);
                const isToday = isSameDay(day, new Date());

                return (
                  <motion.button
                    key={i}
                    whileHover={{ scale: 1.1, zIndex: 20 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => {
                      sounds.playClick();
                      onSelectDate(day);
                      onClose();
                    }}
                    className={`
                      aspect-square flex flex-col items-center justify-center text-sm font-black transition-all border relative overflow-hidden
                      ${isSelected ? 'bg-cyber-blue text-black border-cyber-blue shadow-[0_0_20px_rgba(0,240,255,0.4)]' : 'bg-white/5 border-white/5 hover:border-cyber-blue/40'}
                      ${!isCurrentMonth ? 'opacity-5' : 'opacity-100'}
                      ${isToday && !isSelected ? 'text-cyber-blue' : ''}
                    `}
                  >
                    {isToday && !isSelected && (
                      <div className="absolute top-1 right-1 w-1 h-1 bg-cyber-blue rounded-full animate-pulse" />
                    )}
                    <span className="relative z-10">{format(day, 'd')}</span>
                    {isSelected && (
                      <div className="absolute inset-0 bg-white/20 animate-pulse pointer-events-none" />
                    )}
                  </motion.button>
                );
              })}
            </div>

            <div className="mt-10 flex gap-4 relative z-10">
              <motion.button 
                whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.05)' }}
                whileTap={{ scale: 0.98 }}
                onClick={handleClose}
                className="flex-1 py-4 border border-white/10 text-[10px] font-black uppercase tracking-[0.3em] text-white/40 hover:text-white transition-all flex items-center justify-center gap-2"
              >
                <X size={14} />
                {t('ABORT_SEQUENCE', 'ยกเลิกลำดับ')}
              </motion.button>
            </div>

            {/* Bottom Decorative Bar */}
            <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-cyber-blue/40 to-transparent" />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
