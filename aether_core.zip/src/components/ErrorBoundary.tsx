import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let errorMessage = 'An unexpected error occurred.';
      try {
        // Check if it's a Firestore error JSON
        const parsed = JSON.parse(this.state.error?.message || '');
        if (parsed.error) errorMessage = parsed.error;
      } catch (e) {
        errorMessage = this.state.error?.message || errorMessage;
      }

      return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
          <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mb-8 border border-red-500/40">
            <AlertTriangle size={40} className="text-red-500" />
          </div>
          <h2 className="text-4xl font-black italic uppercase tracking-tighter text-white mb-4">
            System <span className="text-red-500">Failure</span>
          </h2>
          <p className="text-white/40 font-mono text-sm max-w-md mb-12 uppercase tracking-widest leading-relaxed">
            {errorMessage}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="flex items-center gap-3 bg-white text-black font-black px-8 py-4 rounded-xl uppercase italic tracking-tighter hover:bg-red-500 transition-all"
          >
            <RefreshCcw size={20} />
            Reboot System
          </button>
        </div>
      );
    }

    return (this as any).props.children;
  }
}
