import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, X, Palette, Globe, LogOut, User } from 'lucide-react';
import { sounds } from '../utils/sounds';
import { ThemeType, Language } from '../types';

interface ThemeCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: ThemeType;
  onThemeChange: (theme: ThemeType) => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  onLogout: () => void;
  userEmail?: string | null;
}

const THEMES: { id: ThemeType; label: string; thLabel: string; color: string }[] = [
  { id: 'cyberpunk', label: 'Cyberpunk', thLabel: 'ไซเบอร์พังค์', color: '#00F0FF' },
  { id: 'minimal', label: 'Minimal', thLabel: 'มินิมอล', color: '#FFFFFF' },
  { id: 'monochrome', label: 'Monochrome', thLabel: 'ขาวดำ', color: '#333333' },
  { id: 'neon', label: 'Neon', thLabel: 'นีออน', color: '#FF00D6' },
];

export default function ThemeCustomizer({
  isOpen,
  onClose,
  currentTheme,
  onThemeChange,
  currentLanguage,
  onLanguageChange,
  onLogout,
  userEmail
}: ThemeCustomizerProps) {
  const t = (en: string, th: string) => currentLanguage === 'th' ? th : en;

  const handleThemeSelect = (theme: ThemeType) => {
    sounds.playClick();
    onThemeChange(theme);
  };

  const handleLanguageToggle = () => {
    sounds.playClick();
    onLanguageChange(currentLanguage === 'en' ? 'th' : 'en');
  };

  const handleLogout = () => {
    sounds.playTransition();
    onLogout();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-sm bg-black border-l border-white/10 z-[101] p-8 shadow-2xl"
          >
            <div className="flex items-center justify-between mb-12">
              <h2 className="text-4xl font-black italic uppercase tracking-tighter text-white">
                {t('System', 'ระบบ')} <span className="text-cyber-blue">Core</span>
              </h2>
              <button 
                onClick={onClose}
                className="w-12 h-12 flex items-center justify-center border border-white/10 hover:bg-white hover:text-black transition-all rounded-xl"
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-12">
              {/* User Info */}
              <section>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <User size={24} className="text-cyber-blue" />
                  </div>
                  <div>
                    <p className="text-[10px] font-mono text-white/40 uppercase tracking-widest">
                      {t('Authenticated User', 'ผู้ใช้ที่ยืนยันตัวตน')}
                    </p>
                    <p className="text-white font-mono text-sm truncate max-w-[200px]">
                      {userEmail || 'Unknown'}
                    </p>
                  </div>
                </div>
              </section>

              {/* Theme Selection */}
              <section>
                <div className="flex items-center gap-3 mb-6">
                  <Palette size={18} className="text-cyber-blue" />
                  <h3 className="text-xs font-mono text-white/40 uppercase tracking-widest">
                    {t('Visual Theme', 'ธีมการแสดงผล')}
                  </h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {THEMES.map((theme) => (
                    <button
                      key={theme.id}
                      onClick={() => handleThemeSelect(theme.id)}
                      className={`p-4 border rounded-2xl transition-all text-left group relative overflow-hidden ${
                        currentTheme === theme.id 
                          ? 'border-cyber-blue bg-cyber-blue/10' 
                          : 'border-white/10 hover:border-white/30'
                      }`}
                    >
                      <div 
                        className="w-4 h-4 rounded-full mb-3" 
                        style={{ backgroundColor: theme.color }}
                      />
                      <p className={`text-xs font-black uppercase tracking-tighter ${
                        currentTheme === theme.id ? 'text-cyber-blue' : 'text-white/60'
                      }`}>
                        {t(theme.label, theme.thLabel)}
                      </p>
                    </button>
                  ))}
                </div>
              </section>

              {/* Language Selection */}
              <section>
                <div className="flex items-center gap-3 mb-6">
                  <Globe size={18} className="text-cyber-blue" />
                  <h3 className="text-xs font-mono text-white/40 uppercase tracking-widest">
                    {t('Language', 'ภาษา')}
                  </h3>
                </div>
                <button
                  onClick={handleLanguageToggle}
                  className="w-full p-4 border border-white/10 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-all group"
                >
                  <span className="text-white font-black uppercase tracking-tighter italic">
                    {currentLanguage === 'en' ? 'English' : 'ภาษาไทย'}
                  </span>
                  <div className="text-[10px] font-mono text-white/40 group-hover:text-cyber-blue transition-colors">
                    {t('Toggle', 'สลับภาษา')}
                  </div>
                </button>
              </section>

              {/* Logout */}
              <section className="pt-12 border-t border-white/10">
                <button
                  onClick={handleLogout}
                  className="w-full p-6 bg-red-500/10 border border-red-500/20 text-red-500 rounded-2xl flex items-center justify-center gap-4 hover:bg-red-500 hover:text-black transition-all font-black uppercase tracking-tighter italic text-lg"
                >
                  <LogOut size={20} />
                  {t('Terminate Session', 'ออกจากระบบ')}
                </button>
              </section>
            </div>

            <div className="absolute bottom-8 left-8 right-8">
              <p className="text-[10px] font-mono text-white/20 text-center uppercase tracking-[0.3em]">
                AETHER_CORE // Secure Access
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
