import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LogIn, Cpu, Zap, Shield, Activity, Mail, Lock, UserPlus, ArrowRight } from 'lucide-react';
import { sounds } from '../utils/sounds';

interface LoginProps {
  onLogin: () => void;
  onEmailLogin: (email: string, pass: string) => Promise<void>;
  onEmailRegister: (email: string, pass: string) => Promise<void>;
}

export default function Login({ onLogin, onEmailLogin, onEmailRegister }: LoginProps) {
  const [mode, setMode] = useState<'options' | 'email' | 'register'>('options');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const start = () => {
      sounds.playStartup();
      sounds.startAmbientMusic();
    };
    window.addEventListener('click', start, { once: true });
    return () => window.removeEventListener('click', start);
  }, []);

  const handleGoogleLogin = () => {
    sounds.playTransition();
    onLogin();
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    sounds.playClick();
    try {
      if (mode === 'email') {
        await onEmailLogin(email, password);
      } else {
        await onEmailRegister(email, password);
      }
      sounds.playTransition();
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
      setLoading(false);
    }
  };

  const switchMode = (newMode: 'options' | 'email' | 'register') => {
    sounds.playBlip();
    setMode(newMode);
    setError('');
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" 
           style={{ backgroundImage: 'linear-gradient(#00F0FF 1px, transparent 1px), linear-gradient(90deg, #00F0FF 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      {/* Glow Effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyber-blue/20 blur-[120px] rounded-full" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-matrix-green/20 blur-[120px] rounded-full" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.9, rotateY: 45 }}
        animate={{ opacity: 1, scale: 1, rotateY: 0 }}
        transition={{ type: "spring", damping: 20, stiffness: 100 }}
        className="max-w-md w-full bg-black/60 backdrop-blur-2xl border-2 border-white/10 p-12 rounded-[2rem] relative z-10 shadow-[0_0_100px_rgba(0,0,0,1)] overflow-hidden group"
      >
        {/* Scanning Line */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute w-full h-1 bg-cyber-blue/20 blur-[2px] animate-scanline-fast" />
        </div>

        {/* Corner Accents */}
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-cyber-blue/40" />
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-white/10" />
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-white/10" />
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-matrix-green/40" />

        <div className="flex justify-center mb-12 relative">
          <motion.div 
            animate={{ 
              rotate: [0, 10, -10, 0],
              scale: [1, 1.05, 0.95, 1],
              boxShadow: [
                "0 0 20px rgba(0,240,255,0.2)",
                "0 0 40px rgba(0,240,255,0.4)",
                "0 0 20px rgba(0,240,255,0.2)"
              ]
            }}
            transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
            className="w-28 h-28 bg-cyber-blue flex items-center justify-center rounded-3xl relative overflow-hidden"
          >
            <Cpu size={56} className="text-black relative z-10" />
            <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent pointer-events-none" />
          </motion.div>
          
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
            className="absolute inset-0 -m-4 border border-dashed border-white/10 rounded-full pointer-events-none"
          />
        </div>

        <div className="text-center mb-12">
          <motion.h1 
            initial={{ letterSpacing: "0.5em", opacity: 0 }}
            animate={{ letterSpacing: "-0.05em", opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="text-6xl font-black italic text-white mb-2 tracking-tighter uppercase glitch-text"
            data-text="AETHER_CORE"
          >
            AETHER<span className="text-cyber-blue">_</span>CORE
          </motion.h1>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: "60%" }}
            className="h-[1px] bg-cyber-blue/40 mx-auto mb-4"
          />
          <p className="text-white/40 font-mono text-[10px] tracking-[0.5em] uppercase animate-pulse">
            Neural-Sync Schedule Interface
          </p>
        </div>

        <AnimatePresence mode="wait">
          {mode === 'options' ? (
            <motion.div
              key="options"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleGoogleLogin}
                className="w-full bg-white text-black font-black py-6 rounded-2xl text-xl italic uppercase tracking-tighter hover:bg-cyber-blue transition-all shadow-[0_10px_30px_-10px_rgba(0,240,255,0.5)] flex items-center justify-center gap-4 group/btn"
              >
                <LogIn size={24} className="group-hover:translate-x-1 transition-transform" />
                <span>Google Sync</span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => switchMode('email')}
                className="w-full bg-white/5 border border-white/10 text-white font-black py-6 rounded-2xl text-xl italic uppercase tracking-tighter hover:bg-white/10 transition-all flex items-center justify-center gap-4 group/btn"
              >
                <Mail size={24} className="group-hover:translate-x-1 transition-transform" />
                <span>Email Access</span>
              </motion.button>
            </motion.div>
          ) : (
            <motion.form
              key="email-form"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleEmailSubmit}
              className="space-y-6"
            >
              <div className="space-y-4">
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={20} />
                  <input
                    type="email"
                    required
                    placeholder="EMAIL_ADDRESS"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 p-5 pl-12 rounded-xl font-mono text-xs uppercase tracking-widest focus:border-cyber-blue outline-none transition-all text-white"
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={20} />
                  <input
                    type="password"
                    required
                    placeholder="ACCESS_KEY"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 p-5 pl-12 rounded-xl font-mono text-xs uppercase tracking-widest focus:border-cyber-blue outline-none transition-all text-white"
                  />
                </div>
              </div>

              {error && (
                <p className="text-hot-pink font-mono text-[10px] uppercase tracking-widest text-center">
                  Error: {error}
                </p>
              )}

              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                disabled={loading}
                className="w-full bg-cyber-blue text-black font-black py-6 rounded-2xl text-xl italic uppercase tracking-tighter hover:bg-white transition-all shadow-[0_10px_30px_-10px_rgba(0,240,255,0.5)] flex items-center justify-center gap-4 group/btn disabled:opacity-50"
              >
                {loading ? (
                  <Activity size={24} className="animate-spin" />
                ) : (
                  <>
                    {mode === 'email' ? <LogIn size={24} /> : <UserPlus size={24} />}
                    <span>{mode === 'email' ? 'Authorize' : 'Register'}</span>
                  </>
                )}
              </motion.button>

              <div className="flex justify-between items-center px-2">
                <button
                  type="button"
                  onClick={() => switchMode('options')}
                  className="text-white/40 font-mono text-[10px] uppercase tracking-widest hover:text-white transition-colors"
                >
                  Back to options
                </button>
                <button
                  type="button"
                  onClick={() => switchMode(mode === 'email' ? 'register' : 'email')}
                  className="text-cyber-blue font-mono text-[10px] uppercase tracking-widest hover:text-white transition-colors flex items-center gap-2"
                >
                  {mode === 'email' ? 'Create Account' : 'Existing User'}
                  <ArrowRight size={12} />
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="mt-12 flex flex-col items-center gap-2">
          <div className="flex gap-1">
            <div className="w-1 h-1 bg-cyber-blue/40 animate-pulse" />
            <div className="w-1 h-1 bg-cyber-blue/40 animate-pulse delay-75" />
            <div className="w-1 h-1 bg-cyber-blue/40 animate-pulse delay-150" />
          </div>
          <p className="text-white/20 font-mono text-[8px] uppercase tracking-[0.4em]">
            System Ready // v3.0.0_BETA_STABLE
          </p>
        </div>
      </motion.div>
    </div>
  );
}
